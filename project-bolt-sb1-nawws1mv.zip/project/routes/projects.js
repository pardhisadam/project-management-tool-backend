const express = require('express');
const Project = require('../models/Project');
const Task = require('../models/Task');
const auth = require('../middleware/auth');

const router = express.Router();

// @route   GET api/projects
// @desc    Get all projects for a user
// @access  Private
router.get('/', auth, (req, res) => {
  try {
    const projects = Project.findByUserId(req.user.id);
    res.json(projects);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET api/projects/:id
// @desc    Get project by ID
// @access  Private
router.get('/:id', auth, (req, res) => {
  try {
    const project = Project.findById(req.params.id);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner or member
    if (project.ownerId !== req.user.id && !project.members.includes(req.user.id)) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    res.json(project);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST api/projects
// @desc    Create a project
// @access  Private
router.post('/', auth, (req, res) => {
  try {
    const { name, description, members } = req.body;

    // Validate input
    if (!name) {
      return res.status(400).json({ message: 'Name is required' });
    }

    const projectData = {
      name,
      description,
      ownerId: req.user.id,
      members: members || []
    };

    const project = Project.create(projectData);
    res.status(201).json(project);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT api/projects/:id
// @desc    Update a project
// @access  Private
router.put('/:id', auth, (req, res) => {
  try {
    const project = Project.findById(req.params.id);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner
    if (project.ownerId !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const updatedProject = Project.update(req.params.id, req.body);
    res.json(updatedProject);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE api/projects/:id
// @desc    Delete a project
// @access  Private
router.delete('/:id', auth, (req, res) => {
  try {
    const project = Project.findById(req.params.id);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner
    if (project.ownerId !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    // Delete all tasks associated with the project
    const tasks = Task.findByProjectId(req.params.id);
    tasks.forEach(task => {
      Task.delete(task.id);
    });

    // Delete the project
    Project.delete(req.params.id);
    res.json({ message: 'Project deleted' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST api/projects/:id/members
// @desc    Add a member to a project
// @access  Private
router.post('/:id/members', auth, (req, res) => {
  try {
    const { userId } = req.body;
    
    if (!userId) {
      return res.status(400).json({ message: 'User ID is required' });
    }

    const project = Project.findById(req.params.id);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner
    if (project.ownerId !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const updatedProject = Project.addMember(req.params.id, userId);
    res.json(updatedProject);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE api/projects/:id/members/:userId
// @desc    Remove a member from a project
// @access  Private
router.delete('/:id/members/:userId', auth, (req, res) => {
  try {
    const project = Project.findById(req.params.id);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner
    if (project.ownerId !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const updatedProject = Project.removeMember(req.params.id, req.params.userId);
    res.json(updatedProject);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET api/projects/:id/tasks
// @desc    Get all tasks for a project
// @access  Private
router.get('/:id/tasks', auth, (req, res) => {
  try {
    const project = Project.findById(req.params.id);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner or member
    if (project.ownerId !== req.user.id && !project.members.includes(req.user.id)) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const tasks = Task.findByProjectId(req.params.id);
    res.json(tasks);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;