const express = require('express');
const Task = require('../models/Task');
const Project = require('../models/Project');
const auth = require('../middleware/auth');

const router = express.Router();

// @route   GET api/tasks
// @desc    Get all tasks assigned to the user
// @access  Private
router.get('/', auth, (req, res) => {
  try {
    const tasks = Task.findByAssigneeId(req.user.id);
    res.json(tasks);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET api/tasks/:id
// @desc    Get task by ID
// @access  Private
router.get('/:id', auth, (req, res) => {
  try {
    const task = Task.findById(req.params.id);
    
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    // Get the project to check permissions
    const project = Project.findById(task.projectId);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner or member of the project
    if (project.ownerId !== req.user.id && !project.members.includes(req.user.id)) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    res.json(task);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST api/tasks
// @desc    Create a task
// @access  Private
router.post('/', auth, (req, res) => {
  try {
    const { title, description, projectId, assigneeId, status, priority, dueDate } = req.body;

    // Validate input
    if (!title || !projectId) {
      return res.status(400).json({ message: 'Title and project ID are required' });
    }

    // Check if project exists and user has access
    const project = Project.findById(projectId);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner or member of the project
    if (project.ownerId !== req.user.id && !project.members.includes(req.user.id)) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const taskData = {
      title,
      description,
      projectId,
      assigneeId,
      status,
      priority,
      dueDate
    };

    const task = Task.create(taskData);
    res.status(201).json(task);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT api/tasks/:id
// @desc    Update a task
// @access  Private
router.put('/:id', auth, (req, res) => {
  try {
    const task = Task.findById(req.params.id);
    
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    // Get the project to check permissions
    const project = Project.findById(task.projectId);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner or member of the project
    if (project.ownerId !== req.user.id && !project.members.includes(req.user.id)) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const updatedTask = Task.update(req.params.id, req.body);
    res.json(updatedTask);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE api/tasks/:id
// @desc    Delete a task
// @access  Private
router.delete('/:id', auth, (req, res) => {
  try {
    const task = Task.findById(req.params.id);
    
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    // Get the project to check permissions
    const project = Project.findById(task.projectId);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Check if user is owner of the project
    if (project.ownerId !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    Task.delete(req.params.id);
    res.json({ message: 'Task deleted' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;