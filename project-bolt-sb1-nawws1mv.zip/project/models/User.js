const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

// Path to users data file
const dataPath = path.join(__dirname, '../data/users.json');

// Ensure data directory exists
const ensureDataDir = () => {
  const dir = path.join(__dirname, '../data');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(dataPath)) {
    fs.writeFileSync(dataPath, JSON.stringify([]));
  }
};

// Get all users
const getUsers = () => {
  ensureDataDir();
  const data = fs.readFileSync(dataPath, 'utf8');
  return JSON.parse(data);
};

// Save users to file
const saveUsers = (users) => {
  ensureDataDir();
  fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
};

const User = {
  // Find user by ID
  findById: (id) => {
    const users = getUsers();
    return users.find(user => user.id === id);
  },

  // Find user by email
  findByEmail: (email) => {
    const users = getUsers();
    return users.find(user => user.email === email);
  },

  // Create a new user
  create: async (userData) => {
    const users = getUsers();
    
    // Check if user already exists
    if (users.some(user => user.email === userData.email)) {
      throw new Error('User already exists');
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(userData.password, salt);

    // Create new user
    const newUser = {
      id: uuidv4(),
      name: userData.name,
      email: userData.email,
      password: hashedPassword,
      role: userData.role || 'user',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    users.push(newUser);
    saveUsers(users);

    // Return user without password
    const { password, ...userWithoutPassword } = newUser;
    return userWithoutPassword;
  },

  // Update user
  update: async (id, userData) => {
    const users = getUsers();
    const index = users.findIndex(user => user.id === id);
    
    if (index === -1) {
      throw new Error('User not found');
    }

    // Update user data
    const updatedUser = {
      ...users[index],
      ...userData,
      updatedAt: new Date().toISOString()
    };

    // Hash password if it's being updated
    if (userData.password) {
      const salt = await bcrypt.genSalt(10);
      updatedUser.password = await bcrypt.hash(userData.password, salt);
    }

    users[index] = updatedUser;
    saveUsers(users);

    // Return user without password
    const { password, ...userWithoutPassword } = updatedUser;
    return userWithoutPassword;
  },

  // Delete user
  delete: (id) => {
    const users = getUsers();
    const filteredUsers = users.filter(user => user.id !== id);
    
    if (filteredUsers.length === users.length) {
      throw new Error('User not found');
    }
    
    saveUsers(filteredUsers);
    return { message: 'User deleted successfully' };
  },

  // Get all users
  getAll: () => {
    const users = getUsers();
    // Return users without passwords
    return users.map(user => {
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    });
  }
};

module.exports = User;