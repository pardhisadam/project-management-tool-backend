const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

// Path to tasks data file
const dataPath = path.join(__dirname, '../data/tasks.json');

// Ensure data directory exists
const ensureDataDir = () => {
  const dir = path.join(__dirname, '../data');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(dataPath)) {
    fs.writeFileSync(dataPath, JSON.stringify([]));
  }
};

// Get all tasks
const getTasks = () => {
  ensureDataDir();
  const data = fs.readFileSync(dataPath, 'utf8');
  return JSON.parse(data);
};

// Save tasks to file
const saveTasks = (tasks) => {
  ensureDataDir();
  fs.writeFileSync(dataPath, JSON.stringify(tasks, null, 2));
};

const Task = {
  // Find task by ID
  findById: (id) => {
    const tasks = getTasks();
    return tasks.find(task => task.id === id);
  },

  // Get tasks by project ID
  findByProjectId: (projectId) => {
    const tasks = getTasks();
    return tasks.filter(task => task.projectId === projectId);
  },

  // Get tasks by assignee ID
  findByAssigneeId: (assigneeId) => {
    const tasks = getTasks();
    return tasks.filter(task => task.assigneeId === assigneeId);
  },

  // Create a new task
  create: (taskData) => {
    const tasks = getTasks();
    
    const newTask = {
      id: uuidv4(),
      title: taskData.title,
      description: taskData.description || '',
      projectId: taskData.projectId,
      assigneeId: taskData.assigneeId || null,
      status: taskData.status || 'todo',
      priority: taskData.priority || 'medium',
      dueDate: taskData.dueDate || null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    tasks.push(newTask);
    saveTasks(tasks);
    return newTask;
  },

  // Update task
  update: (id, taskData) => {
    const tasks = getTasks();
    const index = tasks.findIndex(task => task.id === id);
    
    if (index === -1) {
      throw new Error('Task not found');
    }

    // Update task data
    const updatedTask = {
      ...tasks[index],
      ...taskData,
      updatedAt: new Date().toISOString()
    };

    tasks[index] = updatedTask;
    saveTasks(tasks);
    return updatedTask;
  },

  // Delete task
  delete: (id) => {
    const tasks = getTasks();
    const filteredTasks = tasks.filter(task => task.id !== id);
    
    if (filteredTasks.length === tasks.length) {
      throw new Error('Task not found');
    }
    
    saveTasks(filteredTasks);
    return { message: 'Task deleted successfully' };
  },

  // Get all tasks
  getAll: () => {
    return getTasks();
  }
};

module.exports = Task;