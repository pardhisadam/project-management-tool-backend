const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

// Path to projects data file
const dataPath = path.join(__dirname, '../data/projects.json');

// Ensure data directory exists
const ensureDataDir = () => {
  const dir = path.join(__dirname, '../data');
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(dataPath)) {
    fs.writeFileSync(dataPath, JSON.stringify([]));
  }
};

// Get all projects
const getProjects = () => {
  ensureDataDir();
  const data = fs.readFileSync(dataPath, 'utf8');
  return JSON.parse(data);
};

// Save projects to file
const saveProjects = (projects) => {
  ensureDataDir();
  fs.writeFileSync(dataPath, JSON.stringify(projects, null, 2));
};

const Project = {
  // Find project by ID
  findById: (id) => {
    const projects = getProjects();
    return projects.find(project => project.id === id);
  },

  // Get projects by user ID
  findByUserId: (userId) => {
    const projects = getProjects();
    return projects.filter(project => 
      project.ownerId === userId || 
      project.members.includes(userId)
    );
  },

  // Create a new project
  create: (projectData) => {
    const projects = getProjects();
    
    const newProject = {
      id: uuidv4(),
      name: projectData.name,
      description: projectData.description || '',
      ownerId: projectData.ownerId,
      members: projectData.members || [],
      status: projectData.status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    projects.push(newProject);
    saveProjects(projects);
    return newProject;
  },

  // Update project
  update: (id, projectData) => {
    const projects = getProjects();
    const index = projects.findIndex(project => project.id === id);
    
    if (index === -1) {
      throw new Error('Project not found');
    }

    // Update project data
    const updatedProject = {
      ...projects[index],
      ...projectData,
      updatedAt: new Date().toISOString()
    };

    projects[index] = updatedProject;
    saveProjects(projects);
    return updatedProject;
  },

  // Delete project
  delete: (id) => {
    const projects = getProjects();
    const filteredProjects = projects.filter(project => project.id !== id);
    
    if (filteredProjects.length === projects.length) {
      throw new Error('Project not found');
    }
    
    saveProjects(filteredProjects);
    return { message: 'Project deleted successfully' };
  },

  // Get all projects
  getAll: () => {
    return getProjects();
  },

  // Add member to project
  addMember: (projectId, userId) => {
    const projects = getProjects();
    const index = projects.findIndex(project => project.id === projectId);
    
    if (index === -1) {
      throw new Error('Project not found');
    }

    if (!projects[index].members.includes(userId)) {
      projects[index].members.push(userId);
      projects[index].updatedAt = new Date().toISOString();
    }

    saveProjects(projects);
    return projects[index];
  },

  // Remove member from project
  removeMember: (projectId, userId) => {
    const projects = getProjects();
    const index = projects.findIndex(project => project.id === projectId);
    
    if (index === -1) {
      throw new Error('Project not found');
    }

    projects[index].members = projects[index].members.filter(id => id !== userId);
    projects[index].updatedAt = new Date().toISOString();

    saveProjects(projects);
    return projects[index];
  }
};

module.exports = Project;